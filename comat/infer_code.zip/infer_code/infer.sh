python infer.py \
--prompt "A red dog and a blue cat are swimming" \
--outdir "examples" \
--pretrained_model_path "stabilityai/stable-diffusion-xl-base-1.0" \
--checkpoint_path PATH_TO_LORA_FOLDER \
--model_type sdxl \
--sdxl_unet_path PATH_TO_UNET_FOLDER