import argparse
import os
from diffusers import StableDiffusionPipeline, DDIMScheduler
import torch
from PIL import Image
from tqdm import tqdm, trange
import sys
from diffusers import AutoencoderKL, DDPMScheduler, StableDiffusionPipeline, UNet2DConditionModel, DDIMScheduler, DPMSolverSDEScheduler, DPMSolverMultistepScheduler
from diffusers import StableDiffusionPipeline, StableDiffusionXLPipeline
from diffusers.utils.import_utils import is_xformers_available
from packaging import version
import pdb
# add parent path to sys.path to import lora_diffusion
# sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# from lora_diffusion import patch_pipe

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--n_iter",
        type=int,
        default=1,
        help="number of iterations to run for each prompt",
    )
    parser.add_argument(
        "--batch_size",
        type=int,
        default=1, 
        help="batch size for each prompt",
    )
    parser.add_argument(
        "--prompt",
        type=str,
        default="you can choose to specify the prompt instead of reading from file",
    )
    parser.add_argument(
        "--outdir",
        type=str,
        nargs="?",
        help="dir to write results to",
        default="../examples" # TODO
    )
    parser.add_argument(
        "--pretrained_model_path",
        type=str,
        default=None,
        # default="checkpoint/color/lora_weight_e357_s124500.pt", # TODO
        help="to load the finetuned checkpoint or not",
    )
    parser.add_argument("--cfg_scale", type=float, default=7.5)
    parser.add_argument("--cfg_rescale", type=float, default=0.0)
    parser.add_argument("--total_step", type=int, default=50)
    parser.add_argument("--revision", type=str, default=None)
    parser.add_argument("--scheduler", type=str, default='DDPM')
    parser.add_argument("--tune_text_encoder", action='store_true')
    parser.add_argument("--checkpoint_path", type=str, default='')
    parser.add_argument("--sdxl_unet_path", type=str, default=None)

    parser.add_argument("--model_type", type=str, default='sd_1_5')


    args = parser.parse_args()
    return args


def image_grid(imgs, rows, cols):
    assert len(imgs) == rows * cols

    w, h = imgs[0].size
    grid = Image.new('RGB', size=(cols * w, rows * h))

    for i, img in enumerate(imgs):
        grid.paste(img, box=(i % cols * w, i // cols * h))
    return grid

def dummy_checker(image, device, dtype):
    return image, None


def main():
    opt = parse_args()
    print(opt)
    

    # load sd
    opt.weight_dtype = torch.float16

    vae_path = 'madebyollin/sdxl-vae-fp16-fix'
    vae = AutoencoderKL.from_pretrained(vae_path, torch_dtype=torch.float16)
    unet_path = opt.sdxl_unet_path
    unet = UNet2DConditionModel.from_pretrained(unet_path, subfolder="unet")
    sdxl_model_path = opt.pretrained_model_path 
    PIPELINE_NAME = StableDiffusionXLPipeline
    pipeline = PIPELINE_NAME.from_pretrained(sdxl_model_path, vae=vae, unet=unet, torch_type=opt.weight_dtype)

    pipeline.unet.to(dtype=opt.weight_dtype)
    pipeline.vae.to(dtype=opt.weight_dtype)
    pipeline.text_encoder.to(dtype=opt.weight_dtype)
    # set grad
    # Freeze vae and text_encoder
    pipeline.vae.requires_grad_(False)
    pipeline.text_encoder.requires_grad_(False)
    pipeline.unet.requires_grad_(False)


    pipeline.run_safety_checker = dummy_checker

    if opt.scheduler == "DPM++":
        pipeline.scheduler = DPMSolverMultistepScheduler.from_config(pipeline.scheduler.config)
    elif opt.scheduler == "DDPM":
        # We train on the simplified learning objective. If we were previously predicting a variance, we need the scheduler to ignore it
        scheduler_opt = {}

        if "variance_type" in pipeline.scheduler.config:
            variance_type = pipeline.scheduler.config.variance_type

            if variance_type in ["learned", "learned_range"]:
                variance_type = "fixed_small"

            scheduler_opt["variance_type"] = variance_type

        pipeline.scheduler = DDPMScheduler.from_config(pipeline.scheduler.config, **scheduler_opt)
    elif opt.scheduler == 'DDIM':
        pipeline.scheduler = DDIMScheduler.from_config(pipeline.scheduler.config)

    pipeline = pipeline.to('cuda')

    # load attention processors
    pipeline.load_lora_weights(opt.checkpoint_path, weight_name="pytorch_lora_weights.safetensors")
    pipeline.fuse_lora()
    for n, p in pipeline.text_encoder.named_parameters():
        if 'lora' in n:
            print('text encoder lora loaded!')
            break

    pipeline = pipeline.to("cuda")

    # if is_xformers_available():
    #     import xformers

    #     xformers_version = version.parse(xformers.__version__)
    #     if xformers_version == version.parse("0.0.16"):
    #         print(
    #             "xFormers 0.0.16 cannot be used for training in some GPUs. If you observe problems during training, please update xFormers to at least 0.0.17. See https://huggingface.co/docs/diffusers/main/en/optimization/xformers for more details."
    #         )
    #     pipeline.enable_xformers_memory_efficient_attention()
    # else:
    #     raise ValueError("xformers is not available. Make sure it is installed correctly")

    # pipeline.enable_attention_slicing() 
    # if opt.model_type == 'sd_1_5':
    #     pipeline.enable_vae_slicing() # for large batch
    # elif opt.model_type == 'sdxl':
    #     pipeline.enable_vae_slicing() # for large batch
    #     # pipeline.enable_vae_tiling() # only for large resolution

    # load data
    prompt = opt.prompt
    assert prompt is not None
    data = [opt.batch_size * [prompt]]

    # run inference
    outpath = opt.outdir
    os.makedirs(outpath, exist_ok=True)
    sample_path = os.path.join(outpath, f"samples")
    os.makedirs(sample_path, exist_ok=True)
    base_count = len(os.listdir(sample_path))
    grid_count = len(os.listdir(outpath)) - 1

    with torch.no_grad():
        for prompts in tqdm(data, desc="data"):
            images = []
            generator = torch.Generator(device="cuda").manual_seed(42)
            for n in trange(opt.n_iter, desc="Sampling"):
                image = pipeline(prompts, generator=generator).images
                generator = torch.Generator(device="cuda").manual_seed(42 + n + 1)
                for i in range(len(image)):
                    image[i].save(os.path.join(sample_path, f"{prompts[0]}_{base_count:06}.png"))
                    images.append(image[i])
                    base_count += 1
            grid = image_grid(images, rows=opt.n_iter, cols=opt.batch_size)
            grid.save(os.path.join(outpath, f'{prompts[0]}-grid-{grid_count:05}.png'))
            grid_count += 1

if __name__ == "__main__":
    main()
