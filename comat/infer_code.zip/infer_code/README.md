Please dowanload the model checkpoint from https://huggingface.co/CaraJ/CoMat_sdxl_ft_unet/sdxl.

Then substitute the path to the directory of lora and unet in `infer.sh`.

Finally, run `bash infer.sh` to obtain the result.